package com.example.rdgp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    RadioGroup rg;
    RadioButton ind,au,fi;
    ImageView i1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        rg=findViewById(R.id.rg);
        ind=findViewById(R.id.ind);
        au=findViewById(R.id.au);
        fi=findViewById(R.id.fi);
        i1=findViewById(R.id.i1);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(ind.isChecked())
                {
                    i1.setImageResource(R.drawable.india);
                }
                else if(au.isChecked())
                {
                    i1.setImageResource(R.drawable.australia);
                }
                else if(fi.isChecked())
                {
                    i1.setImageResource(R.drawable.fiji);
                }
            }
        });
    }
}