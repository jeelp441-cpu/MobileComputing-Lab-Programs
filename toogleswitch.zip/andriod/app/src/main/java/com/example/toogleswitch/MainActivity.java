package com.example.toogleswitch;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox ch1,ch2;
    ToggleButton to1;
    TextView tx1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        tx1 =findViewById(R.id.tx1);
        ch1 =findViewById(R.id.ch1);
        ch2 = findViewById(R.id.ch2);
        to1 = findViewById(R.id.to1);
        ch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (ch1.isChecked()) {
                    tx1.setTextSize(25);
                }
                else  {
                    tx1.setTextSize(20);
                }

            }
        });

        ch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (ch2.isChecked()) {
                    tx1.setTextColor(Color.RED);
                }
                else {
                    tx1.setTextColor(Color.BLACK);
                }

            }
        });
        to1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (to1.isChecked()) {
                    tx1.setTypeface(null, Typeface.BOLD_ITALIC);   // BOLD
                } else {
                    tx1.setTypeface(null, Typeface.NORMAL); // NORMAL
                }

            }
        });
    }
}